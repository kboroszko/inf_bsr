#!/bin/bash

TOTAL_TESTS=0
TESTS_PASSED=0

for i in {1..10}
do
    echo "running test ${i}"
    ((TOTAL_TESTS=TOTAL_TESTS+1))
    timeout 10 python main.py < "tests/${i}.in" > "tests/${i}.prog.out"
    if diff --color "tests/${i}.out" "tests/${i}.prog.out" ; then
        echo "Success"
        ((TESTS_PASSED=TESTS_PASSED+1))
    else
        echo "ERROR"
    fi
done

percent=0
((percent=TESTS_PASSED/TOTAL_TESTS * 100))

echo "Overal score : ${TESTS_PASSED} / ${TOTAL_TESTS}"
echo "percent: ${percent}%"

